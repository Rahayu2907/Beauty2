$(document).ready(function() {
    $("#dropdown").hover(function() {
      $("#dropdownContent").css("display", "block");
    }, function() {
      $("#dropdownContent").css("display", "none");
    });
  });

